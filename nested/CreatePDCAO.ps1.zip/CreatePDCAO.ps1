﻿configuration CreatePDCAO            
{                
     param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds
                
    )              
            
    Import-DscResource -ModuleName PSDesiredStateConfiguration ,xActiveDirectory, xStorage, xNetworking 
    
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$DomainName\$($AdminCreds.UserName)", $AdminCreds.Password)
            
             
    Node localhost
    {             
            
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }            


        Registry DisableUAC
        {
            Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\policies\system"
            ValueName   = "EnableLUA"
            ValueData   = "0"
        }

        xFirewall Firewall
        {
            Name                  = "FPS-ICMP4-ERQ-In"
            Ensure                = "Present"
            Enabled               = "True"
        }
                   
        xWaitforDisk Disk2
        {
             Diskid = '2'
             RetryIntervalSec = 60
             RetryCount = 60
        }
        
        xDisk HDrive
        {
             Diskid = '2'
             DriveLetter = 'H'             
        }        
        
        File ADFiles            
        {            
            DestinationPath = 'H:\NTDS'            
            Type = 'Directory'            
            Ensure = 'Present'    
            DependsOn = "[xDisk]HDrive"        
        }            
                    
        WindowsFeature ADDSInstall             
        {             
            Ensure = "Present"             
            Name = "AD-Domain-Services"             
        }            
                    
        WindowsFeature ADDSTools            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
        }            
                    
        xADDomain FirstDS             
        {                         
            DomainName = $DomainName            
            DomainAdministratorCredential = $DomainCreds             
            SafemodeAdministratorPassword = $DomainCreds            
            DatabasePath = 'H:\NTDS'            
            LogPath = 'H:\NTDS'            
            DependsOn = "[WindowsFeature]ADDSInstall","[File]ADFiles"            
        }            
                                  
    }             
}            
            
 