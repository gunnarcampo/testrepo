﻿configuration CreateDirectory            
{                
     param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds
                
    )              
            
    Import-DscResource -ModuleName PSDesiredStateConfiguration 
    
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$DomainName\$($AdminCreds.UserName)", $AdminCreds.Password)
            
             
    Node localhost
    {             
            
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }            
                
        File ADFiles            
        {            
            DestinationPath = 'C:\SuperDirectory'            
            Type = 'Directory'            
            Ensure = 'Present'                
        }            
                                                      
    }             
}            
            
 