﻿configuration CreateDirectory            
{                
     param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds
                
    )              
            
    Import-DscResource -ModuleName PSDesiredStateConfiguration 
                                 
    Node localhost
    {                                         
        File ADFiles            
        {            
            DestinationPath = 'C:\SuperDirectory'            
            Type = 'Directory'            
            Ensure = 'Present'                
        }            
                                                      
    }             
}            
            
 